import java.io.ObjectInputStream.GetField;

import javax.swing.JFrame;

public class GameFrame extends JFrame {
    public GameFrame() {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        // setLayout(null);
        setSize(845, 850);
        setLocationRelativeTo(null);
    }
}
